import mysql.connector
from datetime import datetime
from tkinter import Tk, Label, Entry, Button, ttk, messagebox, Toplevel

# Database Connection
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your phpMyAdmin username
        password="",  # Replace with your phpMyAdmin password
        database="retail_db"
    )

# Product Management Class
class ProductManager:
    def __init__(self, db_connection):
        self.db_connection = db_connection

    def add_product(self, name, price, stock):
        cursor = self.db_connection.cursor()
        query = "INSERT INTO products (nama_produk, harga_produk, stok) VALUES (%s, %s, %s)"
        cursor.execute(query, (name, price, stock))
        self.db_connection.commit()

    def update_product(self, product_id, name, price, stock):
        cursor = self.db_connection.cursor()
        query = "UPDATE products SET nama_produk = %s, harga_produk = %s, stok = %s WHERE id_produk = %s"
        cursor.execute(query, (name, price, stock, product_id))
        self.db_connection.commit()

    def delete_product(self, product_id):
        cursor = self.db_connection.cursor()
        query = "DELETE FROM products WHERE id_produk = %s"
        cursor.execute(query, (product_id,))
        self.db_connection.commit()

    def get_products(self):
        cursor = self.db_connection.cursor()
        cursor.execute("SELECT * FROM products")
        return cursor.fetchall()

    def update_stock(self, product_id, quantity):
        cursor = self.db_connection.cursor()
        query = "UPDATE products SET stok = stok - %s WHERE id_produk = %s AND stok >= %s"
        cursor.execute(query, (quantity, product_id, quantity))
        self.db_connection.commit()
        return cursor.rowcount > 0

# Transaction Class
class TransactionManager:
    def __init__(self, db_connection):
        self.db_connection = db_connection

    def add_transaction(self, product_id, quantity):
        cursor = self.db_connection.cursor()
        query_price = "SELECT harga_produk FROM products WHERE id_produk = %s"
        cursor.execute(query_price, (product_id,))
        price = cursor.fetchone()[0]

        total_price = price * quantity
        date = datetime.now().strftime('%Y-%m-%d')

        query_transaction = """
        INSERT INTO transactions (id_produk, jumlah_produk, total_harga, tanggal_transaksi)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query_transaction, (product_id, quantity, total_price, date))
        self.db_connection.commit()

    def get_transactions(self):
        cursor = self.db_connection.cursor()
        cursor.execute("SELECT * FROM transactions")
        return cursor.fetchall()

# Admin GUI Class
class AdminApp:
    def __init__(self, root, db_connection):
        self.product_manager = ProductManager(db_connection)
        self.transaction_manager = TransactionManager(db_connection)
        self.root = root
        self.root.title("Admin - Product Management")

        self.setup_gui()

    def setup_gui(self):
        Label(self.root, text="Product Management", font=("Arial", 14, "bold")).grid(row=0, column=0, columnspan=4, pady=10)

        Label(self.root, text="Name").grid(row=1, column=0, padx=5, pady=5)
        self.product_name_entry = Entry(self.root)
        self.product_name_entry.grid(row=1, column=1, padx=5, pady=5)

        Label(self.root, text="Price").grid(row=2, column=0, padx=5, pady=5)
        self.product_price_entry = Entry(self.root)
        self.product_price_entry.grid(row=2, column=1, padx=5, pady=5)

        Label(self.root, text="Stock").grid(row=3, column=0, padx=5, pady=5)
        self.product_stock_entry = Entry(self.root)
        self.product_stock_entry.grid(row=3, column=1, padx=5, pady=5)

        Button(self.root, text="Add Product", command=self.add_product, bg="lightblue").grid(row=4, column=0, padx=5, pady=5)
        Button(self.root, text="Update Product", command=self.update_product, bg="lightgreen").grid(row=4, column=1, padx=5, pady=5)
        Button(self.root, text="Delete Product", command=self.delete_product, bg="tomato").grid(row=4, column=2, padx=5, pady=5)

        self.product_list = ttk.Treeview(self.root, columns=("ID", "Name", "Price", "Stock"), show="headings")
        self.product_list.heading("ID", text="ID")
        self.product_list.heading("Name", text="Name")
        self.product_list.heading("Price", text="Price")
        self.product_list.heading("Stock", text="Stock")
        self.product_list.grid(row=5, column=0, columnspan=4, padx=5, pady=5)

        Button(self.root, text="View Transactions", command=self.view_transactions, bg="lightyellow").grid(row=6, column=0, columnspan=4, pady=10)

        self.load_products()

    def load_products(self):
        for row in self.product_list.get_children():
            self.product_list.delete(row)
        products = self.product_manager.get_products()
        for product in products:
            self.product_list.insert("", "end", values=product)

    def add_product(self):
        name = self.product_name_entry.get()
        price = float(self.product_price_entry.get())
        stock = int(self.product_stock_entry.get())
        self.product_manager.add_product(name, price, stock)
        self.load_products()
        messagebox.showinfo("Success", "Product added successfully")

    def update_product(self):
        selected_item = self.product_list.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "No product selected")
            return

        product_id = self.product_list.item(selected_item[0])['values'][0]
        name = self.product_name_entry.get()
        price = float(self.product_price_entry.get())
        stock = int(self.product_stock_entry.get())
        self.product_manager.update_product(product_id, name, price, stock)
        self.load_products()
        messagebox.showinfo("Success", "Product updated successfully")

    def delete_product(self):
        selected_item = self.product_list.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "No product selected")
            return

        product_id = self.product_list.item(selected_item[0])['values'][0]
        self.product_manager.delete_product(product_id)
        self.load_products()
        messagebox.showinfo("Success", "Product deleted successfully")

    def view_transactions(self):
        transactions_window = Toplevel(self.root)
        transactions_window.title("Transaction History")

        transaction_list = ttk.Treeview(transactions_window, columns=("ID", "Product ID", "Quantity", "Total", "Date"), show="headings")
        transaction_list.heading("ID", text="ID")
        transaction_list.heading("Product ID", text="Product ID")
        transaction_list.heading("Quantity", text="Quantity")
        transaction_list.heading("Total", text="Total")
        transaction_list.heading("Date", text="Date")
        transaction_list.pack(fill="both", expand=True)

        transactions = self.transaction_manager.get_transactions()
        for transaction in transactions:
            transaction_list.insert("", "end", values=transaction)

# User GUI Class
class UserApp:
    def __init__(self, root, db_connection):
        self.transaction_manager = TransactionManager(db_connection)
        self.product_manager = ProductManager(db_connection)
        self.root = root
        self.root.title("User - Transaction Management")

        self.setup_gui()

    def setup_gui(self):
        Label(self.root, text="Transaction", font=("Arial", 14, "bold")).grid(row=0, column=0, columnspan=2, pady=10)

        Label(self.root, text="Product").grid(row=1, column=0, padx=5, pady=5)
        self.product_dropdown = ttk.Combobox(self.root, state="readonly")
        self.product_dropdown.grid(row=1, column=1, padx=5, pady=5)
        self.load_product_dropdown()

        Label(self.root, text="Quantity").grid(row=2, column=0, padx=5, pady=5)
        self.quantity_entry = Entry(self.root)
        self.quantity_entry.grid(row=2, column=1, padx=5, pady=5)

        Button(self.root, text="Add Transaction", command=self.add_transaction, bg="lightblue").grid(row=3, column=0, columnspan=2, pady=10)

    def load_product_dropdown(self):
        products = self.product_manager.get_products()
        self.product_dropdown['values'] = [f"{product[0]} - {product[1]} (Stock: {product[3]})" for product in products]

    def add_transaction(self):
        if not self.product_dropdown.get():
            messagebox.showwarning("Warning", "No product selected")
            return

        product_id = int(self.product_dropdown.get().split(" - ")[0])
        quantity = int(self.quantity_entry.get())

        if self.product_manager.update_stock(product_id, quantity):
            self.transaction_manager.add_transaction(product_id, quantity)
            messagebox.showinfo("Success", "Transaction added successfully")
            self.load_product_dropdown()
        else:
            messagebox.showerror("Error", "Insufficient stock")

# Main Program
# Main Program
if __name__ == "__main__":
    def open_admin():
        login_window.destroy()  # Menutup login window
        admin_root = Tk()
        db_connection = connect_db()
        AdminApp(admin_root, db_connection)
        admin_root.mainloop()

    def open_user():
        login_window.destroy()  # Menutup login window
        user_root = Tk()
        db_connection = connect_db()
        UserApp(user_root, db_connection)
        user_root.mainloop()

    login_window = Tk()
    login_window.title("Login")
    Label(login_window, text="Email").grid(row=0, column=0, padx=5, pady=5)
    email_entry = Entry(login_window)
    email_entry.grid(row=0, column=1, padx=5, pady=5)

    Label(login_window, text="Password").grid(row=1, column=0, padx=5, pady=5)
    password_entry = Entry(login_window, show="*")
    password_entry.grid(row=1, column=1, padx=5, pady=5)

    def login():
        email = email_entry.get()
        password = password_entry.get()

        # Login validation (you can replace this with actual database verification)
        if email == "admin@example.com" and password == "admin123":
            open_admin()
        elif email == "user@example.com" and password == "user123":
            open_user()
        else:
            messagebox.showerror("Error", "Invalid credentials")

    Button(login_window, text="Login", command=login).grid(row=2, column=0, columnspan=2, pady=10)

    login_window.mainloop()

